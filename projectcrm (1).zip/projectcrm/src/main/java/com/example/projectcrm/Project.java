package com.example.projectcrm;

import javax.swing.*;
import java.awt.*;

public class Project {
    public static void main(String[] args) {

        JFrame frame = new JFrame("Start new project");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();//new BorderLayout());
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));


        JLabel title = new JLabel("Create new project");
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        title.setFont(new Font(title.getFont().getName(), Font.PLAIN, 23));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setForeground(Color.blue);

        panel.add(title);



        JPanel labelText = new JPanel();
        labelText.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        JLabel labelN = new JLabel("Name");
        labelN.setForeground(Color.blue);
        JTextField textFieldN = new JTextField();
        textFieldN.setLayout(new BoxLayout(textFieldN, BoxLayout.X_AXIS));
        textFieldN.setPreferredSize(new Dimension(220, 30));
        textFieldN.setMaximumSize(new Dimension(220, 30));
        labelText.add(labelN);
        labelText.add(textFieldN);
        panel.add(labelText);

        JPanel labelTextD = new JPanel(new GridLayout(1, 1, 0, 0));
        JLabel labelD = new JLabel("Description");
        labelD.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        labelD.setForeground(Color.blue);
        labelTextD.add(labelD);
        panel.add(labelTextD);

        JPanel labelTextF = new JPanel(new GridLayout(1, 1, 0, 0));
        JTextArea textFieldD = new JTextArea(10, 10);
        labelTextF.add(textFieldD);
        panel.add(labelTextF);

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> {

            System.out.println("Name:"+textFieldN.getText());
            System.out.println("Description:"+textFieldD.getText());
        });

        panel.add(submitButton,BorderLayout.CENTER);


        frame.getContentPane().add(panel, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }
}

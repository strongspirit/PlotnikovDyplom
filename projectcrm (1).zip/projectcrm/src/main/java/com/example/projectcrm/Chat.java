package com.example.projectcrm;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Chat {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Chat");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel root = new JPanel(new GridLayout(0, 2));
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        DefaultTableModel  tableModel=new  DefaultTableModel();
        JTable jTable = new JTable(tableModel);
        jTable.setFont(new Font(jTable.getFont().getName(), Font.PLAIN, 15));
        tableModel.addColumn("mes");
        tableModel.addColumn("time");
        jTable.getColumn("mes").setPreferredWidth(200);


        JTextField labelB = new JTextField("");
        labelB.setFont(new Font(labelB.getFont().getName(), Font.PLAIN, 23));

        labelB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println(labelB.getText());
                Date nowDate = new Date(System.currentTimeMillis());
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm...");
                tableModel.insertRow(tableModel.getRowCount(), new Object[]{labelB.getText().toString(),sdf.format(nowDate)});


                frame.revalidate();
                frame.repaint();
                labelB.setText("");

            }
        });

        panel.add(jTable,BorderLayout.NORTH);
        panel.add(labelB,BorderLayout.SOUTH);

        DefaultTableModel userList =new  DefaultTableModel();
        JTable usersT = new JTable(userList);
        usersT.setFont(new Font(usersT.getFont().getName(), Font.PLAIN, 17));
        userList.addColumn("user");
        String[] users  ={"Bob","drake","JOJO","YECGAA"};
        for (String user : users)
            userList.insertRow(userList.getRowCount(), new Object[]{user});
        JPanel NN = new JPanel(new BorderLayout());
        NN.add(usersT);

        NN.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        root.add(NN);
        root.add(panel);

        frame.getContentPane().add(root);

        frame.pack();
        frame.setVisible(true);

        frame.setSize(500,500);
    }
}

package com.example.projectcrm;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;
public class Reg {
    Reg() {
        String[] names = {
                "Register new company owner:Login:Password:Name:Email:Phone",
                "Register new company:Name:Description"
        };

        JFrame frame = new JFrame("Reg");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            JPanel panel = new JPanel(new GridLayout(0, 2));//new BorderLayout());
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));


        Map<String, JTextField> inputFields = new HashMap<>();
        frame.getContentPane().setLayout(new BorderLayout());
        for (String name : names) {
            int len = name.split(":").length;
            String[] keys = new String[len-1];
            for (int i = 1;i<len;i++)
                keys[i-1] = name.split(":")[i];
            JLabel title = new JLabel(name.split(":")[0].toString() );
            title.setAlignmentX(Component.CENTER_ALIGNMENT);
            panel.add(title);
            for (String key : keys) {
                JPanel labelText = new JPanel(new GridLayout(1, 2, 2, 2));
                labelText.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
                JLabel label = new JLabel(key + ":");
                JTextField textField = new JTextField();

                labelText.add(label, BorderLayout.WEST);
                labelText.add(textField, BorderLayout.NORTH);

                inputFields.put(name.split(":")[0]+"."+key, textField);

                panel.add(labelText);
            }


            frame.getContentPane().add(panel, BorderLayout.CENTER);
        }

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> {
            for (String key : inputFields.keySet()) {
                    String inputText = inputFields.get(key).getText();
                    System.out.println(key + ": " + inputText);

            }

            frame.setVisible(false);


        });



        frame.getContentPane().add(submitButton, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }
}

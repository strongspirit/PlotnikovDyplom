package com.example.projectcrm;


import javax.swing.*;
import java.awt.*;
import java.util.Calendar;
import java.util.Date;


public class Sprint {
    static Date nowDate = new Date(System.currentTimeMillis()); // right NOW!
    static Date endDate = new Date(System.currentTimeMillis()+1000000);
    static SpinnerDateModel dateModel = new SpinnerDateModel(
            nowDate, nowDate, endDate, Calendar.NARROW_FORMAT);
    public static void main(String[] args) {

        JFrame frame = new JFrame("Start new sprint");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();//new BorderLayout());
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JLabel title = new JLabel("Create new Sprint");
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        title.setFont(new Font(title.getFont().getName(), Font.PLAIN, 23));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setForeground(Color.blue);




        JPanel labelText = new JPanel();
        labelText.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        JLabel labelN = new JLabel("Name");
        labelN.setForeground(Color.blue);
        JTextField textFieldN = new JTextField();
        textFieldN.setLayout(new BoxLayout(textFieldN, BoxLayout.X_AXIS));
        textFieldN.setPreferredSize(new Dimension(220, 30));
        textFieldN.setMaximumSize(new Dimension(220, 30));
        labelText.add(labelN);
        labelText.add(textFieldN);
        panel.add(labelText);


        String sb[] = { "LiudaTest1", "LiudaTest2", "LiudaTest3", "LiudaTest4", "LiudaTest5" };


        JPanel labelSelect = new JPanel();
        labelSelect.setBorder(BorderFactory.createEmptyBorder(0     , 0, 0, 0));
        JLabel labelS = new JLabel("Project");
        labelS.setForeground(Color.blue);
        JComboBox textS = new JComboBox(sb);
        textS.setLayout(new BoxLayout(textS, BoxLayout.X_AXIS));
        textS.setPreferredSize(new Dimension(220, 30));
        textS.setMaximumSize(new Dimension(220, 30));
        labelSelect.add(labelS);
        labelSelect.add(textS);
        panel.add(labelSelect);


        JPanel lSD = new JPanel();
        labelSelect.setBorder(BorderFactory.createEmptyBorder(0     , 0, 0, 0));
        JLabel labelSD = new JLabel("Start Date");
        labelS.setForeground(Color.blue);
        JSpinner panelSD = new JSpinner(dateModel);
        lSD.add(labelSD);
        lSD.add(panelSD);
        panel.add(lSD);

        JPanel lED = new JPanel();
        labelSelect.setBorder(BorderFactory.createEmptyBorder(0     , 0, 0, 0));
        JLabel labelED = new JLabel("End Date");
        labelS.setForeground(Color.blue);
        JSpinner panelED = new JSpinner(dateModel);
        lED.add(labelED);
        lED.add(panelED);
        panel.add(lED);




        JPanel labelTextD = new JPanel(new GridLayout(1, 1, 0, 0));
        JLabel labelG = new JLabel("Goal");
        labelG.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        labelG.setForeground(Color.blue);
        labelTextD.add(labelG);
        panel.add(labelTextD);

        JPanel labelTextF = new JPanel(new GridLayout(1, 1, 0, 0));
        JTextArea textFieldG = new JTextArea(10, 10);
        labelTextF.add(textFieldG);
        panel.add(labelTextF);

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> {

            System.out.println("Name:"+textFieldN.getText());
            System.out.println("Project:"+textS.getSelectedItem());
            System.out.println("Start Date:"+panelSD.getValue());
            System.out.println("END Date:"+(Date)panelED.getValue());
            System.out.println("Goal:"+textFieldG.getText());

        });

        panel.add(submitButton,BorderLayout.CENTER);


        frame.getContentPane().add(panel, BorderLayout.SOUTH);



        frame.pack();
        frame.setVisible(true);
    }
}

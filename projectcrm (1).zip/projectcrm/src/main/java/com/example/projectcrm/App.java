package com.example.projectcrm;

import javax.swing.*;
import java.awt.*;

public class App {
    public static void main(String[] args) {
        var result = new Auth();
        var login = "Admin";

        String[] mainList = {"File","!Company","Project","User Story","Sprint","Time","Statistic","Help","!New user"};


        JFrame frame = new JFrame("App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);




        String[][] tabs = {
                {"To do","To discuss","Backlog","Done","In Progress"},
                {"RENAMED","Created issue","issue","MAJOR","Bla bla bla"},
                {"","Created issue","","",""},
                {"","NAME","","",""},
                {"","HQSBJNAJSASH SHH","","",""},
                {"","To Disc","","",""}
        };
        String[] cols = {"To do","To discuss","Backlog","Done","In Progress"};
        JTable jTable = new JTable(tabs,cols);
        jTable.getTableHeader();
        jTable.setTableHeader(null);
        jTable.setFont(new Font(jTable.getFont().getName(), Font.PLAIN, 20));
        jTable.setForeground(Color.black);


        JPanel tPanel = new JPanel(new GridLayout(0, 3));
        JLabel text  = new JLabel("Test Sprint");

        text.setLayout(new BoxLayout(text, BoxLayout.X_AXIS));
        text.setAlignmentX(Component.CENTER_ALIGNMENT);
        text.setFont(new Font(jTable.getFont().getName(), Font.PLAIN, 20));

        JPanel ltPanel = new JPanel(new GridLayout(2, 0));
        Button button = new Button("19:63");
        Checkbox checkbox = new Checkbox("Assigned to me");
        ltPanel.add(button);
        ltPanel.add(checkbox);

        JPanel rtPanel = new JPanel(new GridLayout(2, 2));
        String pr[] = { "Project","LiudaTest1", "LiudaTest2", "LiudaTest3", "LiudaTest4", "LiudaTest5" };
        String us[] = {"User Story", "Lazy Track", "Doc Brown System", "All fine", "Mem System", "AI???" };
        JLabel pt  = new JLabel("Project");
        JComboBox projectStory = new JComboBox(pr);
        projectStory.setLayout(new BoxLayout(projectStory, BoxLayout.X_AXIS));
        JLabel ut  = new JLabel("User Story");
        JComboBox userStory = new JComboBox(us);
        userStory.setLayout(new BoxLayout(userStory, BoxLayout.X_AXIS));

        rtPanel.add(pt);
        rtPanel.add(projectStory);
        rtPanel.add(ut);
        rtPanel.add(userStory);

        tPanel.add(ltPanel,BorderLayout.EAST);
        tPanel.add(text,BorderLayout.CENTER);
        tPanel.add(rtPanel,BorderLayout.WEST);

        JPanel panel = new JPanel(new GridLayout(2, 0));
        panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));


        panel.add(tPanel,BorderLayout.EAST);
        panel.add(jTable,BorderLayout.NORTH);

        frame.getContentPane().add(panel, BorderLayout.SOUTH);


        JMenuBar mb = new JMenuBar();

        for (String main : mainList) {
            if (main.split("!").length == 2)
                if (!login.equals("Admin"))
                    continue;
            JMenu x = new JMenu(main.replace("!",""));

            mb.add(x);
        }

        frame.setJMenuBar(mb);
        frame.pack();
        frame.setVisible(true);




    }

}

package com.example.projectcrm;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class Auth {
    public String user  ="";

    String UserName(){
        return this.user;
    }

    Auth() {
        JFrame frame = new JFrame("Auth");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        String[] keys = {"Login","Password"};
        JPanel panel = new JPanel(new GridLayout(0, 2));//new BorderLayout());
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50)); // Set padding


        JLabel title = new JLabel("Welcome to Lazy Track");
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        title.setFont(new Font(title.getFont().getName(), Font.PLAIN, 23));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(title);
        Map<String, JTextField> inputFields = new HashMap<>();
        for (String key : keys) {

            JLabel label = new JLabel(key);
            label.setAlignmentX(Component.CENTER_ALIGNMENT);

            JTextField textField = new JTextField();

            panel.add(label);
            textField.setBorder(BorderFactory.createEmptyBorder(4, 0, 5, 0));
            textField.setMaximumSize(new Dimension(10000, 50));
            panel.add(textField);

            inputFields.put(key, textField);


        }

        frame.add(panel);

        JButton logIn = new JButton("Login In"); //new JPanel(new BorderLayout());

        logIn.setPreferredSize(new Dimension(40, 60));
        logIn.addActionListener(e -> {
            for (String key : keys) {
                String inputText = inputFields.get(key).getText();
                System.out.println(key + ": " + inputText);




            }

            if (inputFields.get("Login").getText().equals("Login") && inputFields.get("Password").getText().equals("Password")){
                System.out.println("ROOT");
                user="Admin";
            }
            if (inputFields.get("Login").getText().equals("123") && inputFields.get("Password").getText().equals("123")){
                System.out.println("USER:123");
                user="123";

            }
            frame.setVisible(false);
            return ;
        });

        JButton signIn = new JButton("Sign In");
        signIn.addActionListener(e -> {
            Reg reg = new Reg();

            });

        JPanel btnList = new JPanel(new GridLayout(1, 2, 2, 2));//new BorderLayout());

        btnList.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        btnList.add(logIn, BorderLayout.WEST);
        btnList.add(signIn, BorderLayout.NORTH);

        panel.add(btnList);


        frame.getContentPane().add(panel, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }
}

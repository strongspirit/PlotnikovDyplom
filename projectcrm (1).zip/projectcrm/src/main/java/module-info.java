module com.example.projectcrm {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires json;


    opens com.example.projectcrm to javafx.fxml;
    exports com.example.projectcrm;
}